## removePlayerFromRadio

## Description

Removes the player from the radio

## NOTE: This is just syntactic sugar for `setRadioChannel(0)`

```lua
-- Removes the player from the radio channel
exports['pma-voice']:removePlayerFromRadio()
```