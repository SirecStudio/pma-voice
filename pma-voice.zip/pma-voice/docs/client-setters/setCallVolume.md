## setCallVolume

## Description

Sets the local players call channel volume

## Parameters

* **callVolume**: the call volume to set to between 0 - 100 percent

```lua
-- set the call volume to 50 percent
exports['pma-voice']:setCallVolume(50)
```